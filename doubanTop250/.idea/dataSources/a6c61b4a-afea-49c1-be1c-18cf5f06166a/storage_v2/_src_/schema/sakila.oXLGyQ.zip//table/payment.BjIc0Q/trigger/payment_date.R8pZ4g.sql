create definer = root@localhost trigger payment_date
    before insert
    on payment
    for each row
    SET NEW.payment_date = NOW();

